using namespace System
using namespace System.IO
using namespace System.Text
using namespace System.Text.RegularExpressions

# Get current command path.
[string]$current = $MyInvocation.MyCommand.Path
# Get calling command path.
[string]$calling = @(Get-PSCallStack)[1].InvocationInfo.MyCommand.Path
# If executed directly then...
if ($calling -ne "") {
    $current = $calling
}

# ----------------------------------------------------------------------------

function ConfigureSettings
{
    [FileInfo]$global:ScriptFile = New-Object FileInfo($current);
    # Set public parameters.
	$global:ScriptName = $ScriptFile.Basename;
	$global:ScriptPath = $ScriptFile.Directory.FullName;
    # Cange current dir.
    Write-Host "Current Path: $ScriptPath";
    [Environment]::CurrentDirectory = $ScriptPath;
}

# ----------------------------------------------------------------------------

function Search-Registry {
<#
.SYNOPSIS
Searches registry key names, value names, and value data (limited).
.DESCRIPTION
This function can search registry key names, value names, and value data (in a limited fashion). It outputs custom objects that contain the key and the first match type (KeyName, ValueName, or ValueData).
.EXAMPLE
Search-Registry -Path HKLM:\SYSTEM\CurrentControlSet\Services\* -SearchRegex "svchost" -ValueData
.EXAMPLE
Search-Registry -Path HKLM:\SOFTWARE\Microsoft -Recurse -ValueNameRegex "ValueName1|ValueName2" -ValueDataRegex "ValueData" -KeyNameRegex "KeyNameToFind1|KeyNameToFind2"
#>
    [CmdletBinding()]
    param(
        [Parameter(Mandatory, Position=0, ValueFromPipelineByPropertyName)]
        [Alias("PsPath")]
        # Registry path to search
        [string[]] $Path,
        # Specifies whether or not all subkeys should also be searched
        [switch] $Recurse,
        [Parameter(ParameterSetName="SingleSearchString", Mandatory)]
        # A regular expression that will be checked against key names, value names, and value data (depending on the specified switches)
        [string] $SearchRegex,
        [Parameter(ParameterSetName="SingleSearchString")]
        # When the -SearchRegex parameter is used, this switch means that key names will be tested (if none of the three switches are used, keys will be tested)
        [switch] $KeyName,
        [Parameter(ParameterSetName="SingleSearchString")]
        # When the -SearchRegex parameter is used, this switch means that the value names will be tested (if none of the three switches are used, value names will be tested)
        [switch] $ValueName,
        [Parameter(ParameterSetName="SingleSearchString")]
        # When the -SearchRegex parameter is used, this switch means that the value data will be tested (if none of the three switches are used, value data will be tested)
        [switch] $ValueData,
        [Parameter(ParameterSetName="MultipleSearchStrings")]
        # Specifies a regex that will be checked against key names only
        [string] $KeyNameRegex,
        [Parameter(ParameterSetName="MultipleSearchStrings")]
        # Specifies a regex that will be checked against value names only
        [string] $ValueNameRegex,
        [Parameter(ParameterSetName="MultipleSearchStrings")]
        # Specifies a regex that will be checked against value data only
        [string] $ValueDataRegex
    )
    begin {
        switch ($PSCmdlet.ParameterSetName) {
            SingleSearchString {
                $NoSwitchesSpecified = -not ($PSBoundParameters.ContainsKey("KeyName") -or $PSBoundParameters.ContainsKey("ValueName") -or $PSBoundParameters.ContainsKey("ValueData"))
                if ($KeyName -or $NoSwitchesSpecified) { $KeyNameRegex = $SearchRegex }
                if ($ValueName -or $NoSwitchesSpecified) { $ValueNameRegex = $SearchRegex }
                if ($ValueData -or $NoSwitchesSpecified) { $ValueDataRegex = $SearchRegex }
            }
            MultipleSearchStrings {
                # No extra work needed
            }
        }
    }
    process {
        foreach ($CurrentPath in $Path) {
            $CurrentPath = $CurrentPath -replace '^HKEY_CLASSES_ROOT','HKCR:';
            $CurrentPath = $CurrentPath -replace '^HKEY_CURRENT_CONFIG','HKCC:';
            $CurrentPath = $CurrentPath -replace '^HKEY_CURRENT_USER','HKCU:';
            $CurrentPath = $CurrentPath -replace '^HKEY_LOCAL_MACHINE','HKLM:';
            $CurrentPath = $CurrentPath -replace '^HKEY_USERS','HKU:';
            Get-ChildItem $CurrentPath -Recurse:$Recurse -ErrorAction SilentlyContinue | ForEach-Object {
                $Key = $_;
                if ($KeyNameRegex) {
                    Write-Verbose ("{0}: Checking KeyNamesRegex" -f $Key.Name);
                    if ($Key.PSChildName -match $KeyNameRegex) {
                        Write-Verbose "`t-> Match found!";
                        return [PSCustomObject] @{ Key = $Key; Reason = "KeyName"; };
                    }
                }
                if ($ValueNameRegex) {
                    Write-Verbose ("{0}: Checking ValueNamesRegex" -f $Key.Name);
                    if ($Key.GetValueNames() -match $ValueNameRegex) {
                        Write-Verbose "`t-> Match found!";
                        return [PSCustomObject] @{ Key = $Key; Reason = "ValueName"; }
                    }
                }
                if ($ValueDataRegex) {
                    Write-Verbose ("{0}: Checking ValueDataRegex" -f $Key.Name)
                    if (($Key.GetValueNames() | ForEach-Object { $Key.GetValue($_) }) -match $ValueDataRegex) {
                        Write-Verbose "`t-> Match!"
                        return [PSCustomObject] @{ Key = $Key; Reason = "ValueData"; };
                    }
                }
            }
        }
    }
}

# ----------------------------------------------------------------------------

function RemoveHidGuardian
{
    param($path)
    Write-Host "Removing HID Guardian from $path";
    $date = (Get-Date).ToString("yyyyMMdd_hhmmss");
    $backup = "$($ScriptPath)\SYSTEM.$($date).hiv";
    # If path is current registry key then...
    if ($path -eq "HKLM:\SYSTEM") {
        # Use as hive name.
        $hive = $path;
        Write-Host -NoNewline "Backup $path hive to $backup... ";
        REG SAVE $hive $backup;
    } else {
        Write-Host -NoNewline "Backup to $backup... ";
        [File]::Copy($path, $backup);
        # Load file into registry...
        $hive = "HKLM\_TempSYSTEM";
        Write-Host -NoNewline "Load $path as $hive... ";
        REG LOAD $hive $path;
    }
    # Do search
    $hgKeys = New-Object Collections.Generic.List[string];
    $ccs = Search-Registry -Path $hive -SearchRegex "(Current)?ControlSet[0-9]*" -KeyName;
    foreach ($cc in $ccs) {
        Write-Host Searching in $($cc.Key)...;
        $keys = Search-Registry -Path "$($cc.Key)\Services" -recurse -SearchRegex "^HidGuardian$" -KeyName;
        foreach ($key in $keys) { $hgKeys.Add($key.Key); }
        $keys = Search-Registry -Path "$($cc.Key)\Enum\ROOT\SYSTEM" -recurse -KeyNameRegex "^Service&" -ValueDataRegex "^HidGuardian$";
        foreach ($key in $keys) { $hgKeys.Add($key.Key); }
        $keys = Search-Registry -Path "$($cc.Key)\Control\Class" -Recurse -SearchRegex "HidGuardian" -KeyName -ValueName -ValueData;
        foreach ($key in $keys) { $hgKeys.Add($key.Key); }
    }
    Write-Host "Keys Found:";
    Write-Host;
    foreach ($hgKey in $hgKeys) {
        Write-Host "`t$hgKey";
    }
     Write-Host ""
     Write-Host -NoNewline "Would you like to delete them [Y/N]?: ";
     $kp = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown");
     $m2 = "$($kp.Character)".Replace("`r", "").Replace("`n", "").ToUpper();
     if ("${m2}" -eq "Y"){
        Write-Host ""
        Write-Host "Deleting keys... "
        foreach ($hgKey in $hgKeys) {
            $hgKey = = $hgKey -replace '^HKEY_LOCAL_MACHINE','HKLM:';
            Remove-Item $hgKey -Recurse;
        }
    }
    # End search.
    # If path was not a registry key.
    if ($path -ne "HKLM:\SYSTEM")
    {
        # Unload file.
        Write-Host;
        Write-Host -NoNewline "Unload $hive... ";
        REG UNLOAD $hive;
    }
    Write-Host;
    Write-Host "Done.";
}

# ----------------------------------------------------------------------------

# Clear console Window. Terminal: [CTRL]+[SHIFT]+[P], Type: tclear, [Enter]
Clear-Host;
ConfigureSettings;
# Get all drivers of the system.
$options = New-Object Collections.Generic.List[string];
$list = New-Object Collections.Generic.List[string];
# Add registry hive of current Windows.
$options.Add($list.Count.ToString());
$list.Add("HKLM:\SYSTEM");
# Search hard drives for windows registry hives.
$drives = [DriveInfo]::GetDrives();
for ($i = 0; $i -lt $drives.Count; $i++) {
    $drive = $drives[$i];
    # Skip non-fixed and non-ready drives.
    if ($drive.DriveType -ne "Fixed" -or $drive.IsReady -ne $true){ continue; }
    #Write-Host "$($drive.VolumeLabel) ($($drive.Name))";
    $path = [Path]::Combine($drive.RootDirectory, "Windows\System32\config\SYSTEM");
    $fi = New-Object FileInfo($path);
    # Skip drives without system registry hive.
    if ($fi.Exists -ne $true){ continue; };
    # Skip curent SYSTEM Hive file.
Write-Host "$Env:WinDir";
    if ($fi.FullName.StartsWith($Env:WinDir, [StringComparison]::OrdinalIgnoreCase)){ continue; }
    # Add file to the list.
    $options.Add($list.Count.ToString());
    $list.Add($path);
}
# Add local files.
$hives = $CurrentFile.Directory.GetFiles("SYSTEM");
foreach ($hive in $hives) {
    $options.Add($list.Count.ToString());
    $list.Add($hive.FullName); 
}
# Add local files.
$hives = $CurrentFile.Directory.GetFiles("SYSTEM.hiv");
foreach ($hive in $hives) {
    $options.Add($list.Count.ToString());
    $list.Add($hive.FullName);
}
# If no files found then...
if ($list.Count -eq 0){
    Write-Host "No registry hive files found to uninstall HID Guardian.";
    return;
};

# Show menu.
[string]$global:m = "";
do {
    # Clear screen.
    #Clear-Host
    Write-Host;
    Write-Host "Found registry files to uninstall HID Guardian:";
    Write-Host;
    for ($f = 0; $f -lt $list.Count; $f++) {
        $path = $list[$f];
        Write-Host "  $f - $path";
    }
    Write-Host;
    #$m = Read-Host -Prompt "Type option or press ENTER to exit"
    Write-Host -NoNewline "Type option or press ENTER to exit: ";
    $kp = $host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown");
    $m = "$($kp.Character)".Replace("`r", "").Replace("`n", "");
    Write-Host;
    # Exit it [Enter] pressed.
    if ("${m}" -eq "") {
        break;
    }
    # Process answer:
    if ($options.Contains($m)){
        $f = [Int32]::Parse($m);
        RemoveHidGuardian $list[$f];
        break;
    }
} until ($false);


