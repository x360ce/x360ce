@echo off
::-------------------------------------------------------------
:: Check permissions and run as Administrator.
::-------------------------------------------------------------
ATTRIB %windir%\system32 -h | FINDSTR /I "denied" >nul
IF NOT ERRORLEVEL 1 GOTO:ADM
GOTO:EXE
::-------------------------------------------------------------
:ADM
::-------------------------------------------------------------
:: Create temp batch.
SET tb="%TEMP%\%~n0.tmp.bat"
SET tj="%TEMP%\%~n0.tmp.js"
echo @echo off> %tb%
echo %~d0>> %tb%
echo cd "%~p0">> %tb%
echo call "%~nx0" %1 %2 %3 %4 %5 %6 %7 %8 %9>> %tb%
echo del %tj%>> %tb%
:: Delete itself without generating any error message.
echo (goto) 2^>nul ^& del %tb%>> %tb%
:: Create temp script.
echo var arg = WScript.Arguments;> %tj%
echo var wsh = WScript.CreateObject("WScript.Shell");>> %tj%
echo var sha = WScript.CreateObject("Shell.Application");>> %tj%
echo sha.ShellExecute(arg(0), "", wsh.CurrentDirectory, "runas", 1);>> %tj%
:: Execute as Administrator.
cscript /B /NoLogo %tj% %tb%
GOTO:EOF
::-------------------------------------------------------------
:EXE
::-------------------------------------------------------------

SETLOCAL
:: Get processor architecture.
SET arc=x86
IF "%PROCESSOR_ARCHITECTURE%" == "AMD64" SET arc=x64
:: Get Windqows Version.
SET ver=Win10
FOR /f "tokens=4-5 delims=. " %%i in ('ver') do set VERSION=%%i.%%j
IF "%version%" == "6.0" SET ver=WinVS
IF "%version%" == "6.1" SET ver=WinVS
IF "%version%" == "6.2" SET ver=WinVS
IF "%version%" == "6.3" SET ver=WinVS

:: ------------------------------------------------------------
:: Show menu
:: ------------------------------------------------------------
ECHO.
ECHO Virtual Gamepad Emulation Bus (%ver% %arc%):
ECHO.
ECHO   1 - Install
ECHO   2 - UnInstall
ECHO.
SET /P X=Type Number or press ENTER to exit: 
:: Options:
IF "%X%"=="1" CALL:INS
IF "%X%"=="2" CALL:UNS
pause
GOTO:EOF

:INS
devcon.%arc%.exe install %ver%\ViGEmBus.inf Nefarius\ViGEmBus\Gen1
GOTO:EOF

:UNS
devcon.%arc%.exe remove Root\ViGEmBus
devcon.%arc%.exe remove Nefarius\ViGEmBus\Gen1
GOTO:EOF
